
public class Main {
	
	private static UserInterface UI = new UserInterface();
	
	public static void main(String[] args) {
		UI.begin();
	}

}
